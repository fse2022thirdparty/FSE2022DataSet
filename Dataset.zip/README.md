Each fold corresponds to the processed feature vectors of a project.

For instance, the processed feature vectors of Mozilla project is stored in 

```
mozilla/processed/
```

The sub directories of each 'processed' folder is the data used for different experiments.