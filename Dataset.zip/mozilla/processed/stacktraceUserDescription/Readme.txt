filename_crashing指仅限crashing thread内的
filename_all包含所有threads
其它文件命名同理。
ben为确认benign
third为3rd